"use client";

import { useState } from "react";

export default function Subscribe() {
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const r = await fetch("/api/subscribe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    const j = await r.json().catch(() => ({}));
    setMsg(r.ok ? "Kaydolundu ✓ Her sabah kapanış fiyatını yollayacağız." : (j.error ?? "Hata"));
    if (r.ok) setEmail("");
  }

  return (
    <form onSubmit={submit} className="flex flex-wrap gap-2">
      <input
        className="input flex-1 min-w-[220px]"
        placeholder="E-posta adresin"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <button className="rounded-xl bg-lime-300 px-5 py-2.5 font-bold text-black">
        Günlük fiyatı gönder
      </button>
      {msg && <p className="w-full text-sm text-lime-300">{msg}</p>}
    </form>
  );
}
