import { NextResponse } from "next/server";
import { db } from "@/db";
import { bids, subscribers } from "@/db/schema";
import { getLiveAuction, isBlocked, log } from "@/lib/auction";

export const dynamic = "force-dynamic";

const BANNED = /\b(porn|casino|bahis|viagra|crypto ?pump|escort)\b/i;

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek." }, { status: 400 });
  }

  const str = (k: string) => String(body[k] ?? "").trim();
  const bidder = str("bidder");
  const email = str("email").toLowerCase();
  const adHeadline = str("adHeadline");
  const adBody = str("adBody");
  let adUrl = str("adUrl");
  const adEmoji = str("adEmoji") || "🚀";
  const amount = Number(body.amount);

  if (!bidder || !email || !adHeadline || !adUrl)
    return NextResponse.json({ error: "Tüm zorunlu alanları doldur." }, { status: 400 });
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))
    return NextResponse.json({ error: "Geçerli bir e-posta gir." }, { status: 400 });
  if (!/^https?:\/\//i.test(adUrl)) adUrl = `https://${adUrl}`;
  try {
    new URL(adUrl);
  } catch {
    return NextResponse.json({ error: "Geçerli bir URL gir." }, { status: 400 });
  }
  if (!Number.isFinite(amount) || amount <= 0)
    return NextResponse.json({ error: "Teklif tutarı geçersiz." }, { status: 400 });
  if (adHeadline.length > 70 || adBody.length > 140)
    return NextResponse.json({ error: "Reklam metni çok uzun." }, { status: 400 });
  if (BANNED.test(`${adHeadline} ${adBody} ${adUrl}`))
    return NextResponse.json(
      { error: "Bu içerik editoryal kurallarımıza uymuyor." },
      { status: 400 },
    );
  if (await isBlocked(email))
    return NextResponse.json({ error: "Bu e-posta teklif veremez." }, { status: 403 });

  const live = await getLiveAuction();
  if (amount < live.minNext)
    return NextResponse.json(
      { error: `Minimum teklif $${live.minNext.toLocaleString("en-US")}.` },
      { status: 400 },
    );

  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    req.headers.get("x-real-ip") ??
    null;

  const [row] = await db
    .insert(bids)
    .values({
      auctionId: live.auction.id,
      bidder,
      email,
      amount: amount.toFixed(2),
      adHeadline,
      adBody,
      adUrl,
      adEmoji: [...adEmoji][0] ?? "🚀",
      ip,
    })
    .returning();

  await db
    .insert(subscribers)
    .values({ email, source: "bid" })
    .onConflictDoNothing();
  await log("bid", `${bidder} → $${amount.toLocaleString("en-US")}`);

  return NextResponse.json({ ok: true, bid: { id: row.id, amount: Number(row.amount) } });
}
