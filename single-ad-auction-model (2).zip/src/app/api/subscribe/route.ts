import { NextResponse } from "next/server";
import { db } from "@/db";
import { subscribers } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const { email } = await req.json().catch(() => ({ email: "" }));
  const e = String(email ?? "").trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e))
    return NextResponse.json({ error: "Geçerli bir e-posta gir." }, { status: 400 });
  await db.insert(subscribers).values({ email: e, source: "site" }).onConflictDoNothing();
  return NextResponse.json({ ok: true });
}
