import { cookies } from "next/headers";
import { createHmac, timingSafeEqual } from "crypto";

const COOKIE = "tr_admin";

export function adminPassword() {
  return process.env.ADMIN_PASSWORD || "tekreklam";
}

function secret() {
  return process.env.ADMIN_SECRET || adminPassword() + "::tekreklam-salt";
}

export function makeToken() {
  const exp = Date.now() + 1000 * 60 * 60 * 24 * 14;
  const sig = createHmac("sha256", secret()).update(String(exp)).digest("hex");
  return `${exp}.${sig}`;
}

export function verifyToken(token?: string) {
  if (!token) return false;
  const [expStr, sig] = token.split(".");
  if (!expStr || !sig) return false;
  if (Number(expStr) < Date.now()) return false;
  const expected = createHmac("sha256", secret()).update(expStr).digest("hex");
  try {
    return timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
  } catch {
    return false;
  }
}

export async function isAdmin() {
  const jar = await cookies();
  return verifyToken(jar.get(COOKIE)?.value);
}

export const ADMIN_COOKIE = COOKIE;
